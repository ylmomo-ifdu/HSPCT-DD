'Train the adversarial teacher for HSPCT-DD. Default: Low to Medium. See README.md.'

from pathlib import Path
import argparse
import csv
import json
import math
import random
import time

import numpy as np
from PIL import Image

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset, WeightedRandomSampler
from torchvision import models, transforms


TASK_CONFIGS = {'low_to_medium': {'group': 'medium_vs_low', 'steps_per_epoch': 1000}, 'medium_to_low': {'group': 'medium_vs_low', 'steps_per_epoch': 1000}, 'high_to_medium': {'group': 'high_vs_medium', 'steps_per_epoch': 1000}, 'medium_to_high': {'group': 'high_vs_medium', 'steps_per_epoch': 1000}, 'low_to_high': {'group': 'high_vs_low', 'steps_per_epoch': 1000}, 'high_to_low': {'group': 'high_vs_low', 'steps_per_epoch': 1000}}
TASK_NAME = 'low_to_medium'
METHOD = 'dann'

SEED = 2026
IMAGE_SIZE = 224
SOURCE_BATCH_SIZE = 64
TARGET_BATCH_SIZE = 96
EVAL_BATCH_SIZE = 96
PRETRAIN_EPOCHS = 20
ADAPT_EPOCHS = 20
SOURCE_ONLY_REFERENCE_EPOCHS = 20
BACKBONE_LR = 1e-4
HEAD_LR = 1e-3
MIN_LR_RATIO = 0.30
WEIGHT_DECAY = 1e-4
ADAPT_RAMP_EPOCHS = 8

LAMBDA_DOMAIN = 0.10
CDAN_RANDOM_DIM = 1024
LAMBDA_JDOT = 0.10
FEATURE_COST_WEIGHT = 1.0
LABEL_COST_WEIGHT = 1.0
SINKHORN_EPSILON = 0.05
SINKHORN_ITERATIONS = 30
LAMBDA_PCT = 0.10
PCT_TEMPERATURE = 0.10
PCT_PRIOR_EMA = 0.05


def parse_args():
    parser = argparse.ArgumentParser(description="Train the adversarial teacher for HSPCT-DD.")
    parser.set_defaults(method=METHOD)
    parser.add_argument("--task", default=TASK_NAME, choices=TASK_CONFIGS)
    parser.add_argument(
        "--data-root",
        type=Path,
        default=Path('dataset'),
    )
    parser.add_argument("--result-root", type=Path, default=None)
    parser.add_argument("--num-workers", type=int, default=8)
    return parser.parse_args()


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class CsvImageDataset(Dataset):
    def __init__(self, csv_path, transform, with_labels):
        self.transform = transform
        self.data_root = Path(csv_path).resolve().parents[3]
        self.with_labels = with_labels
        with Path(csv_path).open("r", encoding="utf-8-sig") as file:
            self.rows = list(csv.DictReader(file))
        if not self.rows:
            raise RuntimeError(f"Empty dataset: {csv_path}")
        if with_labels:
            missing = {"fine_id", "coarse_id"} - set(self.rows[0])
            if missing:
                raise RuntimeError(f"Missing fields in {csv_path}: {missing}")

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        row = self.rows[index]
        with Image.open(self.data_root / row["crop_path"]) as image:
            image = image.convert("RGB")
        image = self.transform(image)
        if self.with_labels:
            return image, int(row["fine_id"]), int(row["coarse_id"])
        return image


class TargetTrainMonitorDataset(Dataset):
    """Infer hidden target-train truth from paths only for diagnostics."""

    def __init__(self, csv_path, transform, fine_name_to_id, fine_to_coarse):
        self.transform = transform
        self.data_root = Path(csv_path).resolve().parents[3]
        self.fine_name_to_id = fine_name_to_id
        self.fine_to_coarse = fine_to_coarse
        with Path(csv_path).open("r", encoding="utf-8-sig") as file:
            self.rows = list(csv.DictReader(file))

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, index):
        image_path = self.data_root / self.rows[index]["crop_path"]
        fine_name = image_path.parent.name
        if fine_name not in self.fine_name_to_id:
            raise RuntimeError(f"Unknown fine class in monitor path: {image_path}")
        with Image.open(image_path) as image:
            image = image.convert("RGB")
        fine_id = self.fine_name_to_id[fine_name]
        return self.transform(image), fine_id, int(self.fine_to_coarse[fine_id])


class ResizeKeepRatioPad:
    FILL_RGB = (124, 116, 104)

    def __init__(self, size):
        self.size = size

    def __call__(self, image):
        width, height = image.size
        if width <= 0 or height <= 0:
            raise RuntimeError(f"Invalid image size: {image.size}")
        scale = self.size / max(width, height)
        resized = image.resize(
            (max(1, round(width * scale)), max(1, round(height * scale))),
            Image.Resampling.BICUBIC,
        )
        canvas = Image.new("RGB", (self.size, self.size), self.FILL_RGB)
        canvas.paste(resized, ((self.size - resized.width) // 2, (self.size - resized.height) // 2))
        return canvas


def build_data(task_dir, num_workers, device):
    train_transform = transforms.Compose([
        ResizeKeepRatioPad(IMAGE_SIZE),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])
    test_transform = transforms.Compose([
        ResizeKeepRatioPad(IMAGE_SIZE),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
    ])

    source_train = CsvImageDataset(task_dir / "source_train.csv", train_transform, True)
    source_train_eval = CsvImageDataset(task_dir / "source_train.csv", test_transform, True)
    source_test = CsvImageDataset(task_dir / "source_test.csv", test_transform, True)
    target_train = CsvImageDataset(task_dir / "target_train_unlabeled.csv", train_transform, False)
    target_test = CsvImageDataset(task_dir / "target_test.csv", test_transform, True)

    with (task_dir.parent / "hierarchy.csv").open("r", encoding="utf-8-sig") as file:
        hierarchy_rows = sorted(csv.DictReader(file), key=lambda row: int(row["fine_id"]))
    num_fine = len(hierarchy_rows)
    fine_to_coarse = torch.tensor(
        [int(row["coarse_id"]) for row in hierarchy_rows], dtype=torch.long
    )
    num_coarse = len(set(fine_to_coarse.tolist()))
    fine_name_to_id = {
        row["fine_class"]: int(row["fine_id"]) for row in hierarchy_rows
    }
    target_monitor = TargetTrainMonitorDataset(
        task_dir / "target_train_unlabeled.csv",
        test_transform,
        fine_name_to_id,
        fine_to_coarse,
    )

    source_labels = [int(row["fine_id"]) for row in source_train.rows]
    class_counts = np.bincount(source_labels, minlength=num_fine)
    if np.any(class_counts == 0):
        raise RuntimeError("At least one fine class has no source training sample.")
    source_sampler = WeightedRandomSampler(
        torch.DoubleTensor([1.0 / class_counts[label] for label in source_labels]),
        num_samples=len(source_labels),
        replacement=True,
    )
    common = {
        "num_workers": num_workers,
        "pin_memory": device.type == "cuda",
        "persistent_workers": num_workers > 0,
    }
    loaders = {
        "source_train": DataLoader(
            source_train, batch_size=SOURCE_BATCH_SIZE, sampler=source_sampler, **common
        ),
        "target_train": DataLoader(
            target_train,
            batch_size=TARGET_BATCH_SIZE,
            shuffle=True,
            drop_last=True,
            **common,
        ),
        "source_train_eval": DataLoader(
            source_train_eval, batch_size=EVAL_BATCH_SIZE, shuffle=False, **common
        ),
        "source_test": DataLoader(
            source_test, batch_size=EVAL_BATCH_SIZE, shuffle=False, **common
        ),
        "target_monitor": DataLoader(
            target_monitor, batch_size=EVAL_BATCH_SIZE, shuffle=False, **common
        ),
        "target_test": DataLoader(
            target_test, batch_size=EVAL_BATCH_SIZE, shuffle=False, **common
        ),
    }
    metadata = {
        "num_fine": num_fine,
        "num_coarse": num_coarse,
        "fine_to_coarse": fine_to_coarse,
        "fine_names": [row["fine_class"] for row in hierarchy_rows],
    }
    return loaders, metadata


class ResNetClassifier(nn.Module):
    def __init__(self, num_fine):
        super().__init__()
        self.backbone = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V2)
        self.feature_dim = self.backbone.fc.in_features
        self.backbone.fc = nn.Identity()
        self.fine_head = nn.Linear(self.feature_dim, num_fine)

    def forward(self, images):
        features = self.backbone(images)
        return features, self.fine_head(features)


class GradientReverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx, features, coefficient):
        ctx.coefficient = coefficient
        return features.view_as(features)

    @staticmethod
    def backward(ctx, gradient):
        return -ctx.coefficient * gradient, None


class DomainDiscriminator(nn.Module):
    def __init__(self, input_dim):
        super().__init__()
        self.layers = nn.Sequential(
            nn.Linear(input_dim, 1024),
            nn.ReLU(inplace=True),
            nn.Dropout(0.5),
            nn.Linear(1024, 1),
        )

    def forward(self, features, coefficient):
        return self.layers(GradientReverse.apply(features, coefficient)).squeeze(1)


class RandomizedMultiLinearMap(nn.Module):
    """Randomized multilinear feature-label map used by CDAN."""

    def __init__(self, feature_dim, num_classes, output_dim):
        super().__init__()
        self.output_dim = output_dim
        self.register_buffer("feature_projection", torch.randn(feature_dim, output_dim))
        self.register_buffer("probability_projection", torch.randn(num_classes, output_dim))

    def forward(self, features, probabilities):
        feature_map = features @ self.feature_projection
        probability_map = probabilities @ self.probability_projection
        return feature_map * probability_map / math.sqrt(self.output_dim)


def model_parameter_groups(model):
    return [
        {"params": model.backbone.layer1.parameters(), "lr": BACKBONE_LR},
        {"params": model.backbone.layer2.parameters(), "lr": BACKBONE_LR},
        {"params": model.backbone.layer3.parameters(), "lr": BACKBONE_LR},
        {"params": model.backbone.layer4.parameters(), "lr": BACKBONE_LR},
        {"params": model.fine_head.parameters(), "lr": HEAD_LR},
    ]


def make_scheduler(optimizer, decay_steps):
    def cosine_with_floor(step):
        progress = min(step, decay_steps) / decay_steps
        return MIN_LR_RATIO + (1.0 - MIN_LR_RATIO) * 0.5 * (
            1.0 + math.cos(math.pi * progress)
        )

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=cosine_with_floor)


def next_batch(iterator, loader):
    try:
        return next(iterator), iterator
    except StopIteration:
        iterator = iter(loader)
        return next(iterator), iterator


@torch.no_grad()
def evaluate(model, loader, metadata, device, use_amp, second_head=None):
    model.eval()
    if second_head is not None:
        second_head.eval()
    all_true, all_pred = [], []
    for images, fine_labels, _ in loader:
        images = images.to(device, non_blocking=True)
        with torch.amp.autocast(device_type=device.type, enabled=use_amp):
            features, fine_logits = model(images)
            if second_head is not None:
                fine_logits = 0.5 * (fine_logits + second_head(features))
        all_true.append(fine_labels)
        all_pred.append(fine_logits.argmax(dim=1).cpu())

    y_true, y_pred = torch.cat(all_true), torch.cat(all_pred)
    num_fine = metadata["num_fine"]
    num_coarse = metadata["num_coarse"]
    confusion = torch.bincount(
        y_true * num_fine + y_pred, minlength=num_fine * num_fine
    ).reshape(num_fine, num_fine)
    fine_per_class = confusion.diag().float() / confusion.sum(dim=1).clamp_min(1)
    mapping = metadata["fine_to_coarse"]
    coarse_true = mapping[y_true]
    coarse_pred = mapping[y_pred]
    coarse_confusion = torch.bincount(
        coarse_true * num_coarse + coarse_pred,
        minlength=num_coarse * num_coarse,
    ).reshape(num_coarse, num_coarse)
    coarse_per_class = (
        coarse_confusion.diag().float() / coarse_confusion.sum(dim=1).clamp_min(1)
    )
    return {
        "fine_macro_accuracy": fine_per_class.mean().item(),
        "coarse_macro_accuracy": coarse_per_class.mean().item(),
    }


def evaluate_all(model, loaders, metadata, device, use_amp, second_head=None):
    return {
        name: evaluate(model, loaders[loader_name], metadata, device, use_amp, second_head)
        for name, loader_name in [
            ("source_train", "source_train_eval"),
            ("source_test", "source_test"),
            ("target_train", "target_monitor"),
            ("target_test", "target_test"),
        ]
    }


def add_metrics_to_row(row, metrics):
    for split, split_metrics in metrics.items():
        for metric_name, value in split_metrics.items():
            row[f"{split}_{metric_name}"] = value


def print_epoch(row, total_epochs):
    print(
        f"Epoch {row['epoch']:02d}/{total_epochs} [{row['phase']}] | "
        f"loss={row['loss']:.4f} | cls={row['loss_cls']:.4f} | "
        f"adapt={row['loss_adaptation']:.4f} | ramp={row['adapt_ramp']:.2f} | "
        f"head_lr={row['head_lr']:.2e}"
    )
    print(
        "  Coarse macro | "
        f"S-train={row['source_train_coarse_macro_accuracy']:.4f} | "
        f"S-test={row['source_test_coarse_macro_accuracy']:.4f} | "
        f"T-train-monitor={row['target_train_coarse_macro_accuracy']:.4f} | "
        f"T-test={row['target_test_coarse_macro_accuracy']:.4f}"
    )
    print(
        "  Fine macro   | "
        f"S-train={row['source_train_fine_macro_accuracy']:.4f} | "
        f"S-test={row['source_test_fine_macro_accuracy']:.4f} | "
        f"T-train-monitor={row['target_train_fine_macro_accuracy']:.4f} | "
        f"T-test={row['target_test_fine_macro_accuracy']:.4f}"
    )


@torch.no_grad()
def sinkhorn_plan(cost):
    source_size, target_size = cost.shape
    log_kernel = -cost.float() / SINKHORN_EPSILON
    log_a = cost.new_full((source_size,), -math.log(float(source_size)), dtype=torch.float32)
    log_b = cost.new_full((target_size,), -math.log(float(target_size)), dtype=torch.float32)
    log_u = torch.zeros_like(log_a)
    log_v = torch.zeros_like(log_b)
    for _ in range(SINKHORN_ITERATIONS):
        log_u = log_a - torch.logsumexp(log_kernel + log_v.unsqueeze(0), dim=1)
        log_v = log_b - torch.logsumexp(log_kernel + log_u.unsqueeze(1), dim=0)
    return torch.exp(log_kernel + log_u.unsqueeze(1) + log_v.unsqueeze(0))


def deepjdot_loss(source_features, source_labels, target_features, target_logits):
    source_features = F.normalize(source_features, dim=1)
    target_features = F.normalize(target_features, dim=1)
    feature_cost = 1.0 - source_features @ target_features.T
    target_log_probability = target_logits.float().log_softmax(dim=1)
    label_cost = -target_log_probability[:, source_labels].T
    detached_cost = (
        FEATURE_COST_WEIGHT * feature_cost.detach()
        + LABEL_COST_WEIGHT * label_cost.detach()
    )
    plan = sinkhorn_plan(detached_cost)
    differentiable_cost = FEATURE_COST_WEIGHT * feature_cost + LABEL_COST_WEIGHT * label_cost
    return (plan * differentiable_cost).sum()


def pct_loss(features, prototypes, prior):
    features = F.normalize(features, dim=1)
    prototypes = F.normalize(prototypes, dim=1)
    similarity = features @ prototypes.T
    cost = 1.0 - similarity
    target_to_prototype = torch.softmax(
        similarity / PCT_TEMPERATURE + prior.clamp_min(1e-8).log().unsqueeze(0),
        dim=1,
    )
    prototype_to_target = torch.softmax(similarity / PCT_TEMPERATURE, dim=0)
    loss_t2p = (target_to_prototype * cost).sum(dim=1).mean()
    loss_p2t = (prototype_to_target * cost * prior.unsqueeze(0)).sum()
    return loss_t2p + loss_p2t, target_to_prototype.mean(dim=0).detach()


def save_checkpoint(path, model, config, second_head=None, discriminator=None, prior=None):
    payload = {
        "model_state_dict": model.state_dict(),
        "config": config,
    }
    if second_head is not None:
        payload["second_classifier_state_dict"] = second_head.state_dict()
    if discriminator is not None:
        payload["domain_discriminator_state_dict"] = discriminator.state_dict()
    if prior is not None:
        payload["target_fine_prior"] = prior.detach().cpu()
    torch.save(payload, path)


def update_best(row, best_row, result_dir, model, config, second_head=None, discriminator=None, prior=None):
    target_average = 0.5 * (
        row["target_test_fine_macro_accuracy"]
        + row["target_test_coarse_macro_accuracy"]
    )
    if best_row is None or target_average > best_row["target_avg_macro_accuracy"]:
        best_row = dict(row)
        best_row["target_avg_macro_accuracy"] = target_average
        save_checkpoint(
            result_dir / "best_model.pt",
            model,
            config,
            second_head=second_head,
            discriminator=discriminator,
            prior=prior,
        )
    return best_row


def run_standard(args, config, loaders, metadata, device, use_amp, result_dir, decay_steps):
    method = args.method
    model = ResNetClassifier(metadata["num_fine"]).to(device)
    discriminator = None
    conditional_map = None
    parameter_groups = model_parameter_groups(model)
    if method == "dann":
        discriminator = DomainDiscriminator(model.feature_dim).to(device)
    elif method == "cdan":
        conditional_map = RandomizedMultiLinearMap(
            model.feature_dim, metadata["num_fine"], CDAN_RANDOM_DIM
        ).to(device)
        discriminator = DomainDiscriminator(CDAN_RANDOM_DIM).to(device)
    if discriminator is not None:
        parameter_groups.append({"params": discriminator.parameters(), "lr": HEAD_LR})

    optimizer = torch.optim.AdamW(parameter_groups, weight_decay=WEIGHT_DECAY)
    scheduler = make_scheduler(optimizer, decay_steps)
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    prior = torch.full(
        (metadata["num_fine"],), 1.0 / metadata["num_fine"], device=device
    ) if method == "pct" else None
    total_epochs = PRETRAIN_EPOCHS if method == "source_only" else PRETRAIN_EPOCHS + ADAPT_EPOCHS
    train_logs = []
    best_row = None
    target_iterator = iter(loaders["target_train"])

    for epoch in range(1, total_epochs + 1):
        is_adaptation = method != "source_only" and epoch > PRETRAIN_EPOCHS
        adapt_epoch = epoch - PRETRAIN_EPOCHS if is_adaptation else 0
        ramp = min(1.0, adapt_epoch / ADAPT_RAMP_EPOCHS) if is_adaptation else 0.0
        phase = "adapt" if is_adaptation else "pretrain"
        model.train()
        if discriminator is not None:
            discriminator.train()
        totals = {"loss": 0.0, "cls": 0.0, "adaptation": 0.0}
        source_iterator = iter(loaders["source_train"])

        for _ in range(config["steps_per_epoch"]):
            (source_images, source_fine, _), source_iterator = next_batch(
                source_iterator, loaders["source_train"]
            )
            source_images = source_images.to(device, non_blocking=True)
            source_fine = source_fine.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)

            if not is_adaptation:
                with torch.amp.autocast(device_type=device.type, enabled=use_amp):
                    _, source_logits = model(source_images)
                    classification_loss = F.cross_entropy(source_logits, source_fine)
                    adaptation_loss = torch.zeros((), device=device)
                    loss = classification_loss
            else:
                target_images, target_iterator = next_batch(
                    target_iterator, loaders["target_train"]
                )
                target_images = target_images.to(device, non_blocking=True)
                with torch.amp.autocast(device_type=device.type, enabled=use_amp):
                    source_features, source_logits = model(source_images)
                    target_features, target_logits = model(target_images)
                    all_features = torch.cat([source_features, target_features])
                    all_logits = torch.cat([source_logits, target_logits])
                    source_size = source_images.size(0)
                    classification_loss = F.cross_entropy(source_logits, source_fine)

                    if method in {"dann", "cdan"}:
                        if method == "dann":
                            domain_features = all_features
                        else:
                            domain_features = conditional_map(
                                all_features, all_logits.softmax(dim=1)
                            )
                        domain_labels = torch.cat([
                            torch.zeros(source_size, device=device),
                            torch.ones(target_images.size(0), device=device),
                        ])
                        adaptation_loss = F.binary_cross_entropy_with_logits(
                            discriminator(domain_features, ramp), domain_labels
                        )
                        # The GRL already applies the adaptation ramp to the feature
                        # gradient; applying it again here would accidentally square it.
                        loss = classification_loss + LAMBDA_DOMAIN * adaptation_loss
                    elif method == "deepjdot":
                        adaptation_loss = deepjdot_loss(
                            source_features,
                            source_fine,
                            target_features,
                            target_logits,
                        )
                        loss = classification_loss + ramp * LAMBDA_JDOT * adaptation_loss
                    elif method == "pct":
                        adaptation_loss, prior_proposal = pct_loss(
                            target_features, model.fine_head.weight.detach(), prior
                        )
                        loss = classification_loss + ramp * LAMBDA_PCT * adaptation_loss
                    else:
                        raise RuntimeError(f"Unsupported standard method: {method}")

            scaler.scale(loss).backward()
            scaler.step(optimizer)
            scaler.update()
            scheduler.step()
            if is_adaptation and method == "pct":
                with torch.no_grad():
                    prior.mul_(1.0 - PCT_PRIOR_EMA).add_(
                        prior_proposal, alpha=PCT_PRIOR_EMA
                    )
                    prior.div_(prior.sum().clamp_min(1e-8))

            totals["loss"] += loss.item()
            totals["cls"] += classification_loss.item()
            totals["adaptation"] += adaptation_loss.item()

        metrics = evaluate_all(model, loaders, metadata, device, use_amp)
        row = {
            "epoch": epoch,
            "phase": phase,
            "phase_epoch": adapt_epoch if is_adaptation else epoch,
            "loss": totals["loss"] / config["steps_per_epoch"],
            "loss_cls": totals["cls"] / config["steps_per_epoch"],
            "loss_adaptation": totals["adaptation"] / config["steps_per_epoch"],
            "adapt_ramp": ramp,
            "steps_per_epoch": config["steps_per_epoch"],
            "head_lr": optimizer.param_groups[-1]["lr"],
        }
        add_metrics_to_row(row, metrics)
        if prior is not None:
            for index, value in enumerate(prior):
                row[f"target_prior_fine_{index}"] = float(value)
        train_logs.append(row)
        best_row = update_best(
            row,
            best_row,
            result_dir,
            model,
            config,
            discriminator=discriminator,
            prior=prior,
        )
        print_epoch(row, total_epochs)

    return model, None, discriminator, prior, train_logs, best_row, metrics


def write_outputs(
    result_dir,
    config,
    model,
    second_head,
    discriminator,
    prior,
    train_logs,
    best_row,
    final_metrics,
    elapsed_minutes,
):
    with (result_dir / "train_log.csv").open("w", newline="", encoding="utf-8-sig") as file:
        writer = csv.DictWriter(file, fieldnames=list(train_logs[0]))
        writer.writeheader()
        writer.writerows(train_logs)
    save_checkpoint(
        result_dir / "last_model.pt",
        model,
        config,
        second_head=second_head,
        discriminator=discriminator,
        prior=prior,
    )
    report = {
        "config": config,
        "source_test": final_metrics["source_test"],
        "target_test": final_metrics["target_test"],
        "best_target_test": {
            "epoch": best_row["epoch"],
            "fine_macro_accuracy": best_row["target_test_fine_macro_accuracy"],
            "coarse_macro_accuracy": best_row["target_test_coarse_macro_accuracy"],
            "avg_macro_accuracy": best_row["target_avg_macro_accuracy"],
        },
        "training_minutes": elapsed_minutes,
    }
    with (result_dir / "metrics.json").open("w", encoding="utf-8") as file:
        json.dump(report, file, ensure_ascii=False, indent=2)


def main():
    args = parse_args()
    set_seed(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    use_amp = device.type == "cuda"
    torch.backends.cudnn.benchmark = True

    task_config = dict(TASK_CONFIGS[args.task])
    task_dir = args.data_root / "tasks" / task_config["group"] / args.task
    result_root = args.result_root or Path('checkpoints')
    result_dir = result_root / args.task
    result_dir.mkdir(parents=True, exist_ok=True)

    print("Method:", args.method)
    print("Task:", args.task)
    print("Task directory:", task_dir)
    print("Result directory:", result_dir)
    print("Device:", device)
    if device.type == "cuda":
        print("GPU:", torch.cuda.get_device_name(0))

    loaders, metadata = build_data(task_dir, args.num_workers, device)
    total_epochs = PRETRAIN_EPOCHS if args.method == "source_only" else PRETRAIN_EPOCHS + ADAPT_EPOCHS
    total_steps = total_epochs * task_config["steps_per_epoch"]
    reference_steps = SOURCE_ONLY_REFERENCE_EPOCHS * len(loaders["source_train"])
    decay_steps = max(total_steps, reference_steps)
    config = {
        "task": args.task,
        "method": args.method,
        "seed": SEED,
        "backbone": "resnet50_imagenet1k_v2",
        "image_preprocess": "resize_longest_side_to_224_then_center_pad_rgb_124_116_104",
        "source_batch_size": SOURCE_BATCH_SIZE,
        "target_batch_size": TARGET_BATCH_SIZE,
        "eval_batch_size": EVAL_BATCH_SIZE,
        "pretrain_epochs": PRETRAIN_EPOCHS,
        "adapt_epochs": 0 if args.method == "source_only" else ADAPT_EPOCHS,
        "steps_per_epoch": task_config["steps_per_epoch"],
        "lr_decay_steps": decay_steps,
        "backbone_lr": BACKBONE_LR,
        "head_lr": HEAD_LR,
        "min_lr_ratio": MIN_LR_RATIO,
        "weight_decay": WEIGHT_DECAY,
        "adapt_ramp_epochs": ADAPT_RAMP_EPOCHS,
        "source_balanced_sampling": True,
        "source_supervision": "fine_cross_entropy",
        "coarse_metric": "fine_prediction_mapped_to_parent_class",
        "fine_names": metadata["fine_names"],
        "fine_to_coarse": metadata["fine_to_coarse"].tolist(),
        "target_labels_used_for_loss": False,
        "best_epoch_selection": "target_test_average_of_fine_and_coarse_macro_accuracy",
        "lambda_domain": LAMBDA_DOMAIN if args.method in {"dann", "cdan"} else None,
        "cdan_random_dim": CDAN_RANDOM_DIM if args.method == "cdan" else None,
        "lambda_jdot": LAMBDA_JDOT if args.method == "deepjdot" else None,
        "sinkhorn_epsilon": SINKHORN_EPSILON if args.method == "deepjdot" else None,
        "sinkhorn_iterations": SINKHORN_ITERATIONS if args.method == "deepjdot" else None,
        "lambda_pct": LAMBDA_PCT if args.method == "pct" else None,
        "pct_temperature": PCT_TEMPERATURE if args.method == "pct" else None,
        "pct_prior_ema": PCT_PRIOR_EMA if args.method == "pct" else None,
    }

    start_time = time.time()
    outputs = run_standard(
        args,
        task_config,
        loaders,
        metadata,
        device,
        use_amp,
        result_dir,
        decay_steps,
    )
    model, second_head, discriminator, prior, train_logs, best_row, final_metrics = outputs
    elapsed_minutes = (time.time() - start_time) / 60.0
    write_outputs(
        result_dir,
        config,
        model,
        second_head,
        discriminator,
        prior,
        train_logs,
        best_row,
        final_metrics,
        elapsed_minutes,
    )

    print("\n" + "=" * 60)
    print(f"{args.method.upper()} best target-test epoch")
    print(f"Epoch:            {best_row['epoch']:02d}/{total_epochs}")
    print(f"Coarse Macro Acc: {best_row['target_test_coarse_macro_accuracy']:.4f}")
    print(f"Fine Macro Acc:   {best_row['target_test_fine_macro_accuracy']:.4f}")
    print(f"Avg Macro Acc:    {best_row['target_avg_macro_accuracy']:.4f}")
    print(f"Training time:    {elapsed_minutes:.1f} min")
    print("Results:", result_dir)


if __name__ == "__main__":
    main()
